# hacker-theme


![](https://raw.githubusercontent.com/thelearn-tech/img/main/IMG_20210830_121408.jpg)
<br>
</br>
![](https://img.shields.io/badge/Code_in-HTML-orange)
![](https://img.shields.io/badge/Code_in-CSS-blue)
![](https://img.shields.io/badge/Code_in-JS-pink)
<br>
</br>
![](https://img.shields.io/badge/Maintained-Yes-green)
![](https://img.shields.io/badge/Version-1.0.1-yellow)
<br>
</br>
<a href="https://github.com/thelearn-tech/hacker-theme/issues">
      <img alt="Issues" src="https://img.shields.io/github/issues/thelearn-tech/Friday?color=0088ff" />
<a href="https://github.com/thelearn-tech/hacker-theme/pulls">
      <img alt="Pulls" src="https://img.shields.io/github/issues-pr/thelearn-tech/Friday?color=0088ff" />

</br>

## About
I recreated the the original <a href="https://github.com/pages-themes/hacker">***pages-themes/hacker***</a> in *HTML CSS JS* which was in **markdown** and used **ruby(Jekyll highlighting)** so that this **Hacker theme** page can be use in other server and hosting site others than **GitHub**, which use standard **.html** format.

## usage

just get the file and edit them to your need and your good to go.
## Update
 **Login page**


 **assets fix**


# Absolutely free to use

## resources

Code highlighting from https://github.com/googlearchive/code-prettify


Footer from https://www.w3schools.com/w3css/4/w3.css

Font from https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css
& 
https://fonts.googleapis.com/css?family=Lato
